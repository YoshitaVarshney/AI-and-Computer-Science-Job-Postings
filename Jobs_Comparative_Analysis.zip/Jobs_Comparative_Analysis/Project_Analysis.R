# JOBS DATA ANALYSIS PROJECT

# 1. Set working directory
setwd("Jobs_Comparative_Analysis")

# 2. Import dataset
data <- read.csv("jobs_clean.csv")

# 3. Create output folders
dir.create("Analysis_Results", showWarnings = FALSE)
dir.create("Graphs", showWarnings = FALSE)

# 4. Experience Level vs Salary
salary_exp <- aggregate(salary_usd ~ experience_level, data, mean)
salary_exp <- salary_exp[order(-salary_exp$salary_usd), ]
write.csv(salary_exp, "Analysis_Results/Salary_Experience.csv", row.names = FALSE)

png("Graphs/Salary_by_Experience.png", width = 1200, height = 800)
barplot(salary_exp$salary_usd, names.arg = salary_exp$experience_level,
        main = "Salary by Experience Level", ylab = "Average Salary (USD)")
dev.off()

# 5. Employment Type vs Salary
salary_employment <- aggregate(salary_usd ~ employment_type, data, mean)
write.csv(salary_employment, "Analysis_Results/Salary_by_Employment_Type.csv", row.names = FALSE)

png("Graphs/Salary_by_Employment_Type.png", width = 1200, height = 800)
barplot(salary_employment$salary_usd, names.arg = salary_employment$employment_type,
        main = "Salary by Employment Type", ylab = "Average Salary (USD)")
dev.off()

# 6. Company Size vs Salary
salary_company <- aggregate(salary_usd ~ company_size, data, mean)
write.csv(salary_company, "Analysis_Results/Salary_by_Company_Size.csv", row.names = FALSE)

png("Graphs/Salary_by_Company_Size.png", width = 1200, height = 800)
barplot(salary_company$salary_usd, names.arg = salary_company$company_size,
        main = "Salary by Company Size", ylab = "Average Salary (USD)")
dev.off()

# 7. Remote Work Type vs Salary
data$work_type <- factor(data$remote_ratio,
                         levels = c(0, 50, 100),
                         labels = c("On-site", "Hybrid", "Remote"))
salary_remote <- aggregate(salary_usd ~ work_type, data, mean)
write.csv(salary_remote, "Analysis_Results/Salary_by_Remote_Work_Type.csv", row.names = FALSE)

png("Graphs/Salary_by_Remote_Work_Type.png", width = 1200, height = 800)
barplot(salary_remote$salary_usd, names.arg = salary_remote$work_type,
        main = "Salary by Remote Work Type", ylab = "Average Salary (USD)")
dev.off()

# 8. Industry vs Salary
salary_industry <- aggregate(salary_usd ~ industry, data, mean)
salary_industry <- salary_industry[order(-salary_industry$salary_usd), ]
write.csv(salary_industry, "Analysis_Results/Salary_by_Industry.csv", row.names = FALSE)

png("Graphs/Salary_by_Industry.png", width = 1600, height = 1000)
par(mar = c(5, 12, 5, 2))
barplot(salary_industry$salary_usd, names.arg = salary_industry$industry,
        main = "Salary by Industry", xlab = "Average Salary (USD)",
        horiz = TRUE, las = 1)
dev.off()

# 9. Job Title vs Salary
salary_job <- aggregate(salary_usd ~ job_title, data, mean)
salary_job <- salary_job[order(-salary_job$salary_usd), ]
write.csv(salary_job, "Analysis_Results/Salary_by_Job_Title.csv", row.names = FALSE)

top15_jobs <- head(salary_job, 15)
png("Graphs/Top_15_Salaries_by_Job_Title.png", width = 1600, height = 1000)
par(mar = c(5, 15, 5, 2))
barplot(top15_jobs$salary_usd, names.arg = top15_jobs$job_title,
        main = "Top 15 Highest Paying Job Titles",
        xlab = "Average Salary (USD)", horiz = TRUE, las = 1, cex.names = 0.7)
dev.off()

# 10. Education Required vs Salary
salary_education <- aggregate(salary_usd ~ education_required, data, mean)
write.csv(salary_education, "Analysis_Results/Salary_by_Education.csv", row.names = FALSE)

png("Graphs/Salary_by_Education.png", width = 1200, height = 800)
barplot(salary_education$salary_usd, names.arg = salary_education$education_required,
        main = "Salary by Education Required", ylab = "Average Salary (USD)")
dev.off()

# 11. Experience Level vs Employment Type
employment_exp <- as.data.frame(
  table(Experience_Level = data$experience_level,
        Employment_Type = data$employment_type)
)
colnames(employment_exp)[3] <- "Number_of_Jobs"
write.csv(employment_exp, "Analysis_Results/Experience_vs_Employment_Type.csv",
          row.names = FALSE)

png("Graphs/Experience_vs_Employment_Type.png", width = 1200, height = 800)
barplot(t(as.matrix(table(data$experience_level, data$employment_type))),
        beside = TRUE, main = "Employment Type by Experience Level",
        xlab = "Experience Level", ylab = "Number of Jobs",
        legend.text = TRUE)
dev.off()

print("All 8 comparisons completed successfully!")